## LICENSE Exceptions ##

This file forms part of the Leantime Software for which the following exception is added: Customized files within the
`/custom` directory which merely make function calls to the Leantime Software or customize the behavior to local needs,
and for that purpose include it by reference shall not be considered modifications of the software.
