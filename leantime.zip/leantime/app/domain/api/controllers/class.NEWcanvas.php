<?php

/**
 * - NEWcanvas class - Controller API
 */

namespace leantime\domain\controllers {

    class NEWcanvas extends api\canvas
    {
        protected const CANVAS_NAME = 'NEW';
    }
}
