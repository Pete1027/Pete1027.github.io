<?php

/**
 * - cpcanvas class - Controller API
 */

namespace leantime\domain\controllers {

    class cpcanvas extends api\canvas
    {
        protected const CANVAS_NAME = 'cp';
    }
}
