<?php

/**
 * - dbmcanvas class - Controller API
 */

namespace leantime\domain\controllers {

    class dbmcanvas extends api\canvas
    {
        protected const CANVAS_NAME = 'dbm';
    }
}
