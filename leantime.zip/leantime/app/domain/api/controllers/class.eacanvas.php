<?php

/**
 * - eacanvas class - Controller API
 */

namespace leantime\domain\controllers {

    class eacanvas extends api\canvas
    {
        protected const CANVAS_NAME = 'ea';
    }
}
