<?php

/**
 * - smcanvas class - Controller API
 */

namespace leantime\domain\controllers {

    class goalcanvas extends api\canvas
    {
        protected const CANVAS_NAME = 'goal';
    }
}
