<?php

/**
 * - insightscanvas class - Controller API
 */

namespace leantime\domain\controllers {

    class insightscanvas extends api\canvas
    {
        protected const CANVAS_NAME = 'insights';
    }
}
