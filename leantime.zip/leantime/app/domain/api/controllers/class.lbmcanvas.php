<?php

/**
 * - lbmcanvas class - Controller API
 */

namespace leantime\domain\controllers {

    class lbmcanvas extends api\canvas
    {
        protected const CANVAS_NAME = 'lbm';
    }
}
