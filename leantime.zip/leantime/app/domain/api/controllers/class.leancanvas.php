<?php

/**
 * - leancanvas class - Controller API
 */

namespace leantime\domain\controllers {

    class leancanvas extends api\canvas
    {
        protected const CANVAS_NAME = 'lean';
    }
}
