<?php

/**
 * - obmcanvas class - Controller API
 */

namespace leantime\domain\controllers {

    class obmcanvas extends api\canvas
    {
        protected const CANVAS_NAME = 'obm';
    }
}
