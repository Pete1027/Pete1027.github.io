<?php

/**
 * - riskscanvas class - Controller API
 */

namespace leantime\domain\controllers {

    class riskscanvas extends api\canvas
    {
        protected const CANVAS_NAME = 'risks';
    }
}
