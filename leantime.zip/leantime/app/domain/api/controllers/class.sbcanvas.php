<?php

/**
 * - sbcanvas class - Controller API
 */

namespace leantime\domain\controllers {

    class sbcanvas extends api\canvas
    {
        protected const CANVAS_NAME = 'sb';
    }
}
