<?php

/**
 * - sqcanvas class - Controller API
 */

namespace leantime\domain\controllers {

    class sqcanvas extends api\canvas
    {
        protected const CANVAS_NAME = 'sq';
    }
}
