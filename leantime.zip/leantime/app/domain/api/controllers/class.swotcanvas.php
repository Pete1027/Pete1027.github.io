<?php

/**
 * - swotcanvas class - Controller API
 */

namespace leantime\domain\controllers {

    class swotcanvas extends api\canvas
    {
        protected const CANVAS_NAME = 'swot';
    }
}
