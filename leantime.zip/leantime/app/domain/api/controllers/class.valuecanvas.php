<?php

/**
 * - sqcanvas class - Controller API
 */

namespace leantime\domain\controllers {

    class valuecanvas extends api\canvas
    {
        protected const CANVAS_NAME = 'value';
    }
}
