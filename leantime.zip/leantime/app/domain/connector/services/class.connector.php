<?php

namespace leantime\domain\services\connector {

    class connector
    {


       public function __construct()
       {
       }

    }

}
