<?php

/**
 * Controller / Edit Comments
 */

namespace leantime\domain\controllers {

    class editCanvasComment extends \leantime\domain\controllers\canvas\editCanvasComment
    {
        protected const CANVAS_NAME = 'cp';
    }

}
