<?php

/**
 * Comments
 */

$canvasName = 'cp';
require($this->getTemplatePath('canvas', 'canvasComment.inc.php'));
