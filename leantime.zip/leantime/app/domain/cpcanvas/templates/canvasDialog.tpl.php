<?php

/**
 * Dialog
 */

$canvasName = 'cp';
require($this->getTemplatePath('canvas', 'canvasDialog.inc.php'));
