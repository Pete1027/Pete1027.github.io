<?php

/**
 * Delete Canvas
 */

$canvasName = 'cp';
require($this->getTemplatePath('canvas', 'delCanvas.inc.php'));
