<?php

/**
 * Delete Item
 */

$canvasName = 'cp';
require($this->getTemplatePath('canvas', 'delCanvasItem.inc.php'));
