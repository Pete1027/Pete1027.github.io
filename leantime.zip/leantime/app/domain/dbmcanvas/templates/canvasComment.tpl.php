<?php

/**
 * Comments
 */

$canvasName = 'dbm';
require($this->getTemplatePath('canvas', 'canvasComment.inc.php'));
