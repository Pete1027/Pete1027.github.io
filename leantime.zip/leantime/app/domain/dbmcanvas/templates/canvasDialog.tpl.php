<?php

/**
 * Dialog
 */

$canvasName = 'dbm';
require($this->getTemplatePath('canvas', 'canvasDialog.inc.php'));
