<?php

/**
 * Delete Canvas
 */

$canvasName = 'dbm';
require($this->getTemplatePath('canvas', 'delCanvas.inc.php'));
