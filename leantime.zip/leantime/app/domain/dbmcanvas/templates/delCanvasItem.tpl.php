<?php

/**
 * Delete Item
 */

$canvasName = 'dbm';
require($this->getTemplatePath('canvas', 'delCanvasItem.inc.php'));
