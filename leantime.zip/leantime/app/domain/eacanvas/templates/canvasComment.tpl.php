<?php

/**
 * Comments
 */

$canvasName = 'ea';
require($this->getTemplatePath('canvas', 'canvasComment.inc.php'));
