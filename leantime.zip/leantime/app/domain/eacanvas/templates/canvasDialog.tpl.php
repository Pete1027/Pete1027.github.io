<?php

/**
 * Dialog
 */

$canvasName = 'ea';
require($this->getTemplatePath('canvas', 'canvasDialog.inc.php'));
