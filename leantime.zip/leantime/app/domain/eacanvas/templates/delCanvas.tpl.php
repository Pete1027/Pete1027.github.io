<?php

/**
 * Delete Canvas
 */

$canvasName = 'ea';
require($this->getTemplatePath('canvas', 'delCanvas.inc.php'));
