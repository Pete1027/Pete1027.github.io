<?php

/**
 * Delete Item
 */

$canvasName = 'ea';
require($this->getTemplatePath('canvas', 'delCanvasItem.inc.php'));
