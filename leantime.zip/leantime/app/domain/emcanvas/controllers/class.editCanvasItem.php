<?php

/**
 * Controller / Edit Canvas Item
 */

namespace leantime\domain\controllers {

    class editCanvasItem extends \leantime\domain\controllers\canvas\editCanvasItem
    {
        protected const CANVAS_NAME = 'em';
    }

}
