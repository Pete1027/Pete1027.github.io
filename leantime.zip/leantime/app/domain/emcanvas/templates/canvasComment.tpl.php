<?php

/**
 * Comments
 */

$canvasName = 'em';
require($this->getTemplatePath('canvas', 'canvasComment.inc.php'));
