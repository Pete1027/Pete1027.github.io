<?php

/**
 * Dialog
 */

$canvasName = 'em';
require($this->getTemplatePath('canvas', 'canvasDialog.inc.php'));
