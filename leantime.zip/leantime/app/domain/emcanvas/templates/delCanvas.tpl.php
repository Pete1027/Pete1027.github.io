<?php

/**
 * Delete Canvas
 */

$canvasName = 'em';
require($this->getTemplatePath('canvas', 'delCanvas.inc.php'));
