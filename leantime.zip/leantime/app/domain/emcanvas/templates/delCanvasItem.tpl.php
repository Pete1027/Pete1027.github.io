<?php

/**
 * Delete Item
 */

$canvasName = 'em';
require($this->getTemplatePath('canvas', 'delCanvasItem.inc.php'));
