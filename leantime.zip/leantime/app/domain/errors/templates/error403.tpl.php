<?php defined('RESTRICTED') or die('Restricted access'); ?>

<div class="errortitle">

    <h4 class="animate0 fadeInUp"><?php echo $this->__('headlines.page_forbidden') ?></h4>
    <span class="animate1 bounceIn">4</span>
    <span class="animate2 bounceIn">0</span>
    <span class="animate3 bounceIn">3</span>
    <div class="errorbtns animate4 fadeInUp">
        <a onclick="history.back()" class="btn btn-default"><?php echo $this->__('buttons.back') ?></a>
        <a href="<?=BASE_URL ?>" class="btn btn-primary"><?php echo $this->__('links.dashboard') ?></a>
    </div><br/><br/><br/><br/>

</div>
