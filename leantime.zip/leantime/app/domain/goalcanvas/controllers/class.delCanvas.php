<?php

/**
 * Controller / Delete Canvas
 */

namespace leantime\domain\controllers {

    class delCanvas extends \leantime\domain\controllers\canvas\delCanvas
    {
        protected const CANVAS_NAME = 'goal';
    }
}
