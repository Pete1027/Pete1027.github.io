<?php

/**
 * Comments
 */

$canvasName = 'goal';
require($this->getTemplatePath('canvas', 'canvasComment.inc.php'));
