<?php

/**
 * Delete Canvas
 */

$canvasName = 'goal';
require($this->getTemplatePath('canvas', 'delCanvas.inc.php'));
