<?php

/**
 * Delete Item
 */

$canvasName = 'goal';
require($this->getTemplatePath('canvas', 'delCanvasItem.inc.php'));
