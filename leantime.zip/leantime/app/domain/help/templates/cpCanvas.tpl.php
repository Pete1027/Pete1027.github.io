<?php

$canvasName = 'cp';
require(ROOT . '/../app/domain/canvas/templates/helper.inc.php');
