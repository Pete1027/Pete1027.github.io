<?php

$canvasName = 'dbm';
require(ROOT . '/../app/domain/canvas/templates/helper.inc.php');
