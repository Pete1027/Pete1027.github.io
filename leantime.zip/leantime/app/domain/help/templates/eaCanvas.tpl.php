<?php

$canvasName = 'ea';
require(ROOT . '/../app/domain/canvas/templates/helper.inc.php');
