<?php

$canvasName = 'goal';
require(ROOT . '/../app/domain/canvas/templates/helper.inc.php');
