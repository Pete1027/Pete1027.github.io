<?php

$canvasName = 'insights';
require(ROOT . '/../app/domain/canvas/templates/helper.inc.php');
