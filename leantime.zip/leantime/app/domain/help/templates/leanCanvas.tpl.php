<?php

$canvasName = 'lean';
require(ROOT . '/../app/domain/canvas/templates/helper.inc.php');
