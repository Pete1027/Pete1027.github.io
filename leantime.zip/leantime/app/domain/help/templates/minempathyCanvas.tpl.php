<?php

$canvasName = 'minempathy';
require(ROOT . '/../app/domain/canvas/templates/helper.inc.php');
