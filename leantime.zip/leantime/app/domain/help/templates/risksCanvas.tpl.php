<?php

$canvasName = 'risks';
require(ROOT . '/../app/domain/canvas/templates/helper.inc.php');
