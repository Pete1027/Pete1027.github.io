<?php

$canvasName = 'sb';
require(ROOT . '/../app/domain/canvas/templates/helper.inc.php');
