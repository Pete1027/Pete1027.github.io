<?php

$canvasName = 'swot';
require(ROOT . '/../app/domain/canvas/templates/helper.inc.php');
