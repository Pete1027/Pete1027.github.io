<?php

/**
 * Comments
 */

$canvasName = 'insights';
require($this->getTemplatePath('canvas', 'canvasComment.inc.php'));
