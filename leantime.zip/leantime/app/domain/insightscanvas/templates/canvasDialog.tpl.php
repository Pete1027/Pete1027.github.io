<?php

/**
 * Dialog
 */

$canvasName = 'insights';
require($this->getTemplatePath('canvas', 'canvasDialog.inc.php'));
