<?php

/**
 * Delete Canvas
 */

$canvasName = 'insights';
require($this->getTemplatePath('canvas', 'delCanvas.inc.php'));
