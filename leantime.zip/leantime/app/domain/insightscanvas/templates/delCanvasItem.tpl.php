<?php

/**
 * Delete Item
 */

$canvasName = 'insights';
require($this->getTemplatePath('canvas', 'delCanvasItem.inc.php'));
