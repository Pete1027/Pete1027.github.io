<?php

/**
 * Controller
 */

namespace leantime\domain\controllers {

    class showCanvas extends \leantime\domain\controllers\canvas\showCanvas
    {
        protected const CANVAS_NAME = 'lbm';
    }

}
