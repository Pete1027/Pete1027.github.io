<?php

/**
 * Comments
 */

$canvasName = 'lbm';
require($this->getTemplatePath('canvas', 'canvasComment.inc.php'));
