<?php

/**
 * Dialog
 */

$canvasName = 'lbm';
require($this->getTemplatePath('canvas', 'canvasDialog.inc.php'));
