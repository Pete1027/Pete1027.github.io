<?php

/**
 * Delete Canvas
 */

$canvasName = 'lbm';
require($this->getTemplatePath('canvas', 'delCanvas.inc.php'));
