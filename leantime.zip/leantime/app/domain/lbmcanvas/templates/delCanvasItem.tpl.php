<?php

/**
 * Delete Item
 */

$canvasName = 'lbm';
require($this->getTemplatePath('canvas', 'delCanvasItem.inc.php'));
