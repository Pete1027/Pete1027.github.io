<?php

/**
 * Comments
 */

$canvasName = 'lean';
require($this->getTemplatePath('canvas', 'canvasComment.inc.php'));
