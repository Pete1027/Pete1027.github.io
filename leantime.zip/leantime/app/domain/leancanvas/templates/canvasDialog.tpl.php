<?php

/**
 * Dialog
 */

$canvasName = 'lean';
require($this->getTemplatePath('canvas', 'canvasDialog.inc.php'));
