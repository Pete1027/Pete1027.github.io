<?php

/**
 * Delete Canvas
 */

$canvasName = 'lean';
require($this->getTemplatePath('canvas', 'delCanvas.inc.php'));
