<?php

/**
 * Delete Item
 */

$canvasName = 'lean';
require($this->getTemplatePath('canvas', 'delCanvasItem.inc.php'));
