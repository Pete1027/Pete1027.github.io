<?php

/**
 * Comments
 */

$canvasName = 'risks';
require($this->getTemplatePath('canvas', 'canvasComment.inc.php'));
