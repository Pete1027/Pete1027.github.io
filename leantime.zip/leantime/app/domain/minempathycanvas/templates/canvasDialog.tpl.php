<?php

/**
 * Dialog
 */

$canvasName = 'minempathy';
require($this->getTemplatePath('canvas', 'canvasDialog.inc.php'));
