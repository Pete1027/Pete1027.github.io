<?php

/**
 * Delete Canvas
 */

$canvasName = 'minempathy';
require($this->getTemplatePath('canvas', 'delCanvas.inc.php'));
