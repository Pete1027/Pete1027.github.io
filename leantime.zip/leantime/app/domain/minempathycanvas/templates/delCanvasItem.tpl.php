<?php

/**
 * Delete Item
 */

$canvasName = 'minempathy';
require($this->getTemplatePath('canvas', 'delCanvasItem.inc.php'));
