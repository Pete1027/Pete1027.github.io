<?php

/**
 * Controller / Delete Canvas Item
 */

namespace leantime\domain\controllers {

    class delCanvasItem extends \leantime\domain\controllers\canvas\delCanvasItem
    {
        protected const CANVAS_NAME = 'obm';
    }

}
