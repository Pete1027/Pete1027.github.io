<?php

/**
 * Comments
 */

$canvasName = 'obm';
require($this->getTemplatePath('canvas', 'canvasComment.inc.php'));
