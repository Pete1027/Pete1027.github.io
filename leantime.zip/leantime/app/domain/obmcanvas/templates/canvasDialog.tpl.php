<?php

/**
 * Dialog
 */

$canvasName = 'obm';
require($this->getTemplatePath('canvas', 'canvasDialog.inc.php'));
