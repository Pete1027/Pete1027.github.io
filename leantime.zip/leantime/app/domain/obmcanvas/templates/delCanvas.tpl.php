<?php

/**
 * Delete Canvas
 */

$canvasName = 'obm';
require($this->getTemplatePath('canvas', 'delCanvas.inc.php'));
