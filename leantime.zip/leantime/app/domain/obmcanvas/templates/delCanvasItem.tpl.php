<?php

/**
 * Delete Item
 */

$canvasName = 'obm';
require($this->getTemplatePath('canvas', 'delCanvasItem.inc.php'));
