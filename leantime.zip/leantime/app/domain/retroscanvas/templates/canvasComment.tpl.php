<?php

/**
 * Comments
 */

$canvasName = 'retros';
require($this->getTemplatePath('canvas', 'canvasComment.inc.php'));
