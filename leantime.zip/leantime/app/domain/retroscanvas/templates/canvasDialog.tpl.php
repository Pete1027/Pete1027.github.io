<?php

/**
 * Dialog
 */

$canvasName = 'retros';
require($this->getTemplatePath('canvas', 'canvasDialog.inc.php'));
