<?php

/**
 * Delete Canvas
 */

$canvasName = 'retros';
require($this->getTemplatePath('canvas', 'delCanvas.inc.php'));
