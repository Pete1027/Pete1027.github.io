<?php

/**
 * Delete Item
 */

$canvasName = 'retros';
require($this->getTemplatePath('canvas', 'delCanvasItem.inc.php'));
