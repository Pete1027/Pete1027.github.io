<?php

/**
 * Dialog
 */

$canvasName = 'risks';
require($this->getTemplatePath('canvas', 'canvasDialog.inc.php'));
