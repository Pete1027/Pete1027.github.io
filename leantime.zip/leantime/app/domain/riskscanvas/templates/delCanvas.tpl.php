<?php

/**
 * Delete Canvas
 */

$canvasName = 'risks';
require($this->getTemplatePath('canvas', 'delCanvas.inc.php'));
