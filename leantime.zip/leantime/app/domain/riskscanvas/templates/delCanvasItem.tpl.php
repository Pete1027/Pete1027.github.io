<?php

/**
 * Delete Item
 */

$canvasName = 'risks';
require($this->getTemplatePath('canvas', 'delCanvasItem.inc.php'));
